<?php
$id = $_POST['id'];
$nome = $_POST['nome'];
$email = $_POST['email'];

// Conecta no PostgreSQL (host,port,db, user, senha)
$conexao = pg_connect("host=localhost port=5432 dbname=livro user=livro password=livro123");

// SQL INSERT
if($id) {
	$query = "update usuario set nome = '$nome', email = '$email' where id=$id";
}
else {
	$query = "INSERT INTO usuario(nome,email,data_cadastro) VALUES ('$nome', '$email',now())";
}


$resultado = pg_query($conexao, $query);

pg_free_result($resultado);
pg_close($conexao);

// Redireciona para a lista
header( 'Location: index.php' ) ;
?>
