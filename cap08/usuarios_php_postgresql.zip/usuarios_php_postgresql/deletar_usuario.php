<?php
$id = $_GET['id'];

// Conecta no PostgreSQL (host,port,db, user, senha)
$conexao = pg_connect("host=localhost port=5432 dbname=livro user=livro password=livro123");

// SQL INSERT
$query = "delete from usuario where id=$id";

$resultado = pg_query($conexao, $query);

pg_free_result($resultado);
pg_close($conexao);

// Redireciona para a lista
header( 'Location: index.php' ) ;
?>
