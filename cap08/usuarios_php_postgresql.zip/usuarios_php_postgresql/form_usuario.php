<?php
$id = $_GET['id'];

// Conecta no PostgreSQL (host,port,db, user, senha)
$conexao = pg_connect("host=localhost port=5432 dbname=livro user=livro password=livro123");

// SQL
$query = "select id,nome,email from usuario where id=$id";
$resultado = pg_query($conexao, $query);
$linha = pg_fetch_array($resultado);

$nome = $linha['nome'];
$email = $linha['email'];

pg_free_result($resultado);
pg_close($conexao);

?>

<html>
<head>
  <title>Form</title>
</head>
<body>
<h1>Cadastro de Usuário</h1>
  <form method="post" action="salvar_usuario.php">
	<input type="hidden" id="id" name="id" value="<?php echo $id ?>" />
    <p>Nome:</p>
    <input type="text" id="nome" name="nome" value="<?php echo $nome ?>" />
    <p>Email:</p>
    <input type="text" id="email" name="email" value="<?php echo $email ?>" />
	<br>
    <input type="submit" value="Salvar" />
  </form>
</body>
</html>