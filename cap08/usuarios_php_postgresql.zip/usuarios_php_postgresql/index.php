<h1>Lista de Usuarios - PHP Postgres</h1>
<table border="1">
<tr>
   <td width="50px"><b>ID</b></td>
   <td width="200px"><b>Nome</b></td>
   <td width="200px"><b>Email</b></td>
   <td width="100px"><b>Data Cadastro</b></td>
   <td width="100px"><b>Ação</b></td>
</tr>
<?php
// Conecta no PostgreSQL (host,port,db, user, senha)
$conexao = pg_connect("host=localhost port=5432 dbname=livro user=livro password=livro123");

// SQL
$query = "SELECT id,nome,email,data_cadastro FROM usuario ORDER BY id";
$resultado = pg_query($conexao, $query);
while ($linha = pg_fetch_array($resultado)) {
?>
   <tr>
      <td><?php echo $linha['id']; ?></td>
      <td><?php echo $linha['nome']; ?></td>
      <td><?php echo $linha['email']; ?></td>
      <td><?php echo $linha['data_cadastro']; ?></td>
          <td><a href="form_usuario.php?id=<?php echo $linha['id']; ?>">Editar</a> | <a href="deletar_usuario.php?id=<?php echo $linha['id']; ?>">Deletar</a></td>
   </tr>
<?php
}
// Fecha a conexao
pg_free_result($resultado);
pg_close($conexao);
?>
</table>
<p>
<a href="form_usuario.php">Novo</a>
</p>
</body>
</html>
