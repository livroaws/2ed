<h1>Lista de Usuários</h1>
<table border="1">
<tr>
   <td width="50px"><b>ID</b></td>
   <td width="200px"><b>Nome</b></td>
   <td width="200px"><b>Email</b></td>
   <td width="100px"><b>Data Cadastro</b></td>
   <td width="100px"><b>Ação</b></td>
</tr>
<?php
// Conecta no MySQL (host, user, senha)
$conexao = mysql_connect("localhost", "livro", "livro123") or die('erro'); 

// Conecta no banco de dados "livro"
mysql_select_db("livro",$conexao) or die('erro 2');

// SQL
$query = "SELECT id,nome,email,data_cadastro FROM usuario ORDER BY id";
$resultado = mysql_query($query,$conexao);
while ($linha = mysql_fetch_array($resultado)) {
?>
   <tr>
      <td><?php echo $linha['id']; ?></td>
      <td><?php echo $linha['nome']; ?></td>
      <td><?php echo $linha['email']; ?></td>
      <td><?php echo $linha['data_cadastro']; ?></td>
	  <td><a href="form_usuario.php?id=<?php echo $linha['id']; ?>">Editar</a> | <a href="deletar_usuario.php?id=<?php echo $linha['id']; ?>">Deletar</a></td>
   </tr>
<?php
}
// Fecha a conexão
mysql_close($conexao); 
?>
</table>
<p>
<a href="form_usuario.php">Novo</a>
</p>
</body>
</html>