<?php
$id = $_POST['id'];
$nome = $_POST['nome'];
$email = $_POST['email'];

// Conecta no MySQL (host, user, senha)
$conexao = mysql_connect("localhost", "livro", "livro123") or die('erro'); 

// Conecta no banco de dados "livro"
mysql_select_db("livro",$conexao) or die('erro 2');

// SQL INSERT
if($id) {
	$query = "update usuario set nome = '$nome', email = '$email' where id=$id";
}
else {
	$query = "INSERT INTO usuario(nome,email,data_cadastro) VALUES ('$nome', '$email',now())";
}


$resultado = mysql_query($query,$conexao);

mysql_close($conexao);

// Redireciona para a lista
header( 'Location: index.php' ) ;
?>
