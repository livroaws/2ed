<?php
$id = $_GET['id'];

// Conecta no MySQL (host, user, senha)
$conexao = mysql_connect("localhost", "livro", "livro123") or die('erro'); 

// Conecta no banco de dados "livro"
mysql_select_db("livro",$conexao) or die('erro 2');

// SQL INSERT
$query = "delete from usuario where id=$id";

mysql_query($query,$conexao);

mysql_close($conexao);

// Redireciona para a lista
header( 'Location: index.php' ) ;
?>
